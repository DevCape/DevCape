<!-- ============================================================
     SPIDER-MAN GITHUB PROFILE — DevWrapped Theme
     Theme: Spider-Verse | ID: spiderman
     Built with: SMIL SVG animations, GitHub Actions, spider-lore
     ============================================================ -->

<!-- HERO INTRO -->
<p align="center">
  <a href="https://github.com/DevCape">
    <img src="assets/hero.svg" alt="Spider-Sense: ALBERTO CAPELLINI, Friendly Neighborhood Developer" width="100%"/>
  </a>
</p>

<!-- ============================================================
     SECTION 02 — HERO PROFILE
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="https://readme-typing-svg.demolab.com?font=Impact&weight=900&size=42&duration=3000&pause=1.5&color=E62429&center=true&vCenter=true&multiline=true&repeat=true&width=750&height=100&lines=ALBERTO+CAPELLINI;COMPUTER+SCIENCE+STUDENT" alt="ALBERTO CAPELLINI" />
  </a>
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%F0%9F%94%B4-PASSIVE_INCOME_ARCHITECT-E62429?style=for-the-badge&labelColor=081426" alt="Passive Income Architect">
  <img src="https://img.shields.io/badge/%F0%9F%92%BB-SYSTEMS_THINKER-1976D2?style=for-the-badge&labelColor=081426" alt="Systems Thinker">
  <img src="https://img.shields.io/badge/%F0%9F%A6%80+AI_NATIVE-E62429?style=for-the-badge&labelColor=081426" alt="AI Native">
  <img src="https://img.shields.io/badge/%F0%9F%8C%8D+REMOTE-FIRST-2BD576?style=for-the-badge&labelColor=081426" alt="Remote First">
</p>

<p align="center">
  <i>"With great code comes great responsibility."</i><br/>
  <sub>Built <b>PulseWatch</b> (uptime SaaS) — a product that runs while I sleep.</sub>
</p>

<!-- ============================================================
     SECTION 03 — SPIDER-SENSE STATUS
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="assets/spider-sense.svg" alt="Spider-Sense: Online" width="100%">
  </a>
</p>

<!-- ============================================================
     SECTION 04 — HERO STATS (spider-lore terminology)
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%E2%9A%A1+HERO+STATS-FF3340?style=for-the-badge&labelColor=081426&color=E62429" alt="Hero Stats">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="assets/hero-stats.svg" alt="Hero Stats — commits, PRs, streak, stars" width="100%">
  </a>
</p>

<!-- ============================================================
     SECTION 05 — WEB STREAK
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%F0%9F%94%A5+WEB+STREAK-E62429?style=for-the-badge&labelColor=081426&color=FF3340" alt="Web Streak">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="assets/streak-stats.svg" alt="Web Streak — total contributions, current and longest streak" width="100%">
  </a>
</p>

<!-- ============================================================
     SECTION 06 — WEB ARSENAL
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%F0%9F%94%A5+WEB+ARSENAL-FF3340?style=for-the-badge&labelColor=081426&color=E62429" alt="Web Arsenal">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="assets/web-arsenal.svg" alt="Web Arsenal — developer toolbox with real brand icons" width="100%">
  </a>
</p>

<!-- ============================================================
     SECTION 07 — WEB SWING (52-week activity)
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="assets/web-swing.svg" alt="Web Swing — 52-week activity skyline" width="100%">
  </a>
</p>

<!-- ============================================================
     SECTION 08 — CURRENT MISSION (flagship project)
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%F0%9F%8E%AF+CURRENT+MISSION-E62429?style=for-the-badge&labelColor=081426&color=FF3340" alt="Current Mission">
</p>

<p align="center"><i>No flagship project yet — add one in the generator.</i></p>

<!-- ============================================================
     SECTION 09 — WEB MISSIONS (project cards)
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%F0%9F%8E%AF+WEB+MISSIONS-1976D2?style=for-the-badge&labelColor=081426" alt="Web Missions">
</p>

<p align="center"><i>No missions yet — add projects in the generator.</i></p>

<!-- ============================================================
     SECTION 10 — HERO ACHIEVEMENTS
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%F0%9F%8F%86+HERO+ACHIEVEMENTS-E62429?style=for-the-badge&labelColor=081426&color=FF3340" alt="Hero Achievements">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="assets/achievements.svg" alt="Hero Achievements — Spider-Verse Comic Badges" width="100%">
  </a>
</p>

<!-- ============================================================
     SECTION 11 — CONTRIBUTION GRAPH
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%F0%9F%8F%99%EF%B8%8F+CONTRIBUTION+GRAPH-1976D2?style=for-the-badge&labelColor=081426&color=E62429" alt="Contribution Graph">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="https://github-readme-activity-graph.vercel.app/graph?username=DevCape&bg_color=081426&color=E62429&line=FF3340&point=EAF2FF&area=true&area_color=1976D2&hide_border=true&custom_title=CONTRIBUTION%20ACTIVITY%20GRAPH" alt="Activity Graph" width="100%">
  </a>
</p>

<!-- ============================================================
     SECTION 12 — SPIDER-SENSE NETWORK (socials)
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <img src="https://img.shields.io/badge/%F0%9F%93%A1+SPIDER-SENSE+NETWORK-1976D2?style=for-the-badge&labelColor=081426" alt="Spider-Sense Network">
</p>

<p align="center">
  <a href="www.linkedin.com/in/alberto-capellini-596679346"><img src="https://img.shields.io/badge/LinkedIn-E62429?style=for-the-badge&logo=linkedin&logoColor=EAF2FF&labelColor=081426" alt="LinkedIn"></a>
  <a href="mailto:info.acapellini@gmail.com"><img src="https://img.shields.io/badge/Email-1976D2?style=for-the-badge&logo=gmail&logoColor=EAF2FF&labelColor=081426" alt="Email"></a>
</p>

<p align="center"><i>Open to collaborations, freelance work, and building things that make the neighborhood better.</i></p>

<p align="center">
  <i>Open to collaborations, consultations, and friendly neighborhood developer meetups.</i>
</p>

<!-- ============================================================
     SECTION 13 — FOOTER
     ============================================================ -->
<p align="center">
  <img src="assets/web-divider.svg" alt="" width="100%">
</p>

<p align="center">
  <a href="https://github.com/DevCape">
    <img src="assets/footer.svg" alt="The web never sleeps. Neither does the developer." width="100%">
  </a>
</p>

<!-- Visitor Counter (optional) -->
<p align="center">
  <img src="https://komarev.com/ghpvc/?username=DevCape&color=E62429&style=for-the-badge&label=SPIDER-SENSE+VISITORS&labelColor=081426" alt="Visitor Count">
</p>

<p align="center">
  <i>Generated with the <a href="https://github.com/Robibiruk/spiderman-github-readme">Spider-Man GitHub Readme Generator</a> — your friendly neighborhood README builder.</i>
</p>

<!--
SPIDER-SENSE DATA STAMP
Hero stats + streak + achievements + arsenal + swing are rendered by
tools/generate.py from your live GitHub data and refreshed by
.github/workflows/refresh.yml (Mon & Thu, 06:17 UTC).

To refresh manually:
  python tools/generate.py --username DevCape

Optional: set GITHUB_TOKEN in your environment before running to enable
the real 52-week contribution calendar (the GraphQL endpoint needs a token).
-->